# clubShin
A project for agriculture for programmers at shining stars primary
